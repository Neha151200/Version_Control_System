#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>


void compareFiles(FILE *fp1,char *file1, FILE *fp2,char *file2);

int search_file(char *filename,char *search);
